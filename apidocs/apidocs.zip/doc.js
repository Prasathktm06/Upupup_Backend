 
 /*......................................../*
         Get Region
 /*......................................../*
/**
  *@api{get}place/region  Get Region
  *@apiSampleRequest off
  *@apiName getRegion
  *@apiGroup Place
  *@apiVersion 0.1.0
  *@apiDescription  Get all Region.
  *

  *
  *@apiSampleRequest off
  *@apiSuccessExample Example data on success:
  *{
      "id" : "1",
      "term" : "term",
      "parent_term_id" : "0",
      "meaning" : "meaning",
      "phrases" : "noun",
      "language_key" : "en",
      "term_day" : "2016-10-18",
      "status" : "1",
      "updated_on" : "2016-12-08 17:58:17",
      "categories" : "category"
  *}
  *@apiErrorExample  Error-Response:
  *{
    "error":"Error",
    "status": "False" 
  *}  
*/

/*......................................../*
         Check new updates
 /*......................................../*
/**
  *@api{get}term/check_update  Check update
  *@apiSampleRequest off
  *@apiName checkUpdate
  *@apiGroup Terms
  *@apiVersion 0.1.0
  *@apiDescription  Check update.
  *
  *@apiParam {String} date Last updated date(yyyy-mm-dd)
  *
  *@apiSampleRequest off
  *@apiSuccessExample Example data on success:
  *{
      "status" : "true"
  *} 
*/
 /*......................................../*
         Get terms by date
 /*......................................../*
/**
  *@api{get}term/update_terms_get  Get Terms by date
  *@apiSampleRequest off
  *@apiName getTermsByDate
  *@apiGroup Terms
  *@apiVersion 0.1.0
  *@apiDescription  Get all terms By Date.
  *
  *@apiParam {Number} term_id Last recevied term id
  *@apiParam {Number} limit Number of terms per request
  *@apiParam {String} date(yyyy-mm-dd)
  *
  *@apiSampleRequest off
  *@apiSuccessExample Example data on success:
  *{
      "id" : "1",
      "term" : "term",
      "parent_term_id" : "0",
      "meaning" : "meaning",
      "phrases" : "noun",
      "language_key" : "en",
      "term_day" : "2016-10-18",
      "status" : "1",
      "updated_on" : "2016-12-08 17:58:17",
      "categories" : "category"
  *}
  *@apiErrorExample  Error-Response:
  *{
    "error":"Error",
    "status": "False" 
  *}  
*/
